#ifndef __SHOWVECTOR
#define __SHOWVECTOR

#include <string>
#include <vector>

using namespace std;

string ShowVector(vector <unsigned int> vecteur);

#endif
